#! /bin/bash

tar -czvf forge-go-base.tar.gz .
mv forge-go-base.tar.gz ../forge-go/package